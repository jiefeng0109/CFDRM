import torch.optim as optim
from torch import nn
from torch.autograd import Variable
import torch
import time
from models.resnet import resnet50, resnet18
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
import os
import numpy as np
import json
import random
import cv2


class VehicleDatasetIteration(Dataset):

    def __init__(self, obj_list, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.names_list = os.listdir(root_dir)
        self.obj_list = obj_list
        self.size = len(self.obj_list)

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        obj = self.obj_list[idx]
        image = obj['image']
        image = torch.tensor(image.transpose(2, 0, 1)).float()
        sample = {'image': image, 'label': obj['label']}
        return sample


def train_resnet_iteration(dets_file, pre_dets_file, epoch=15, batch_size=1024, root_path=r"D:\Liang\Jilin\SD"):
    with open(dets_file, 'r') as rf:
        dets = json.load(rf)
        if 'annotations' in dets:
            dets = dets['annotations']

    with open(pre_dets_file, 'r') as rf:
        dets_pre = json.load(rf)
        if 'annotations' in dets_pre:
            dets_pre = dets_pre['annotations']

    obj_list = []
    for img_name in os.listdir(os.path.join(root_path, 'val')):
        image_path = os.path.join(root_path, 'val', img_name)
        image = np.load(image_path).astype(np.uint8)
        img_id = int(img_name.split('_')[0])
        bboxes_pre = np.array([i['bbox'] for i in dets_pre if i['image_id'] == img_id]).astype(float)
        bboxes = np.array([i['bbox'] for i in dets if i['image_id'] == img_id]).astype(float)
        bboxes_pre[:, 2] = bboxes_pre[:, 0] + bboxes_pre[:, 2]
        bboxes_pre[:, 3] = bboxes_pre[:, 1] + bboxes_pre[:, 3]
        for bbox in bboxes:
            bbox[2], bbox[3] = bbox[0] + bbox[2], bbox[1] + bbox[3]
            ixmin = np.maximum(bboxes_pre[:, 0], bbox[0])
            iymin = np.maximum(bboxes_pre[:, 1], bbox[1])
            ixmax = np.minimum(bboxes_pre[:, 2], bbox[2])
            iymax = np.minimum(bboxes_pre[:, 3], bbox[3])
            iw = np.maximum(ixmax - ixmin + 1., 0.)
            ih = np.maximum(iymax - iymin + 1., 0.)
            inters = iw * ih
            uni = ((bbox[2] - bbox[0] + 1.) * (bbox[3] - bbox[1] + 1.) +
                   (bboxes_pre[:, 2] - bboxes_pre[:, 0] + 1.) *
                   (bboxes_pre[:, 3] - bboxes_pre[:, 1] + 1.) - inters)
            overlaps = inters / uni
            ovmax = np.max(overlaps)
            if ovmax > 0.8:
                bbox[0], bbox[1] = max(int(bbox[0]), 0), max(int(bbox[1]), 0)
                bbox[2], bbox[3] = min(int(bbox[2]), 500), min(int(bbox[3]), 500)
                img_crop = image[int(bbox[1]):int(bbox[3]), int(bbox[0]):int(bbox[2])]
                img_save = np.zeros((32, 32, 9))
                img_save[:, :, 0:3] = cv2.resize(img_crop[:, :, 0:3], (32, 32))
                img_save[:, :, 3:6] = cv2.resize(img_crop[:, :, 3:6], (32, 32))
                img_save[:, :, 6:9] = cv2.resize(img_crop[:, :, 6:9], (32, 32))
                obj = {'image': img_save, 'label': 1}
                obj_list.append(obj)
                if random.random() < 0.8:
                    bbox[0], bbox[1] = max(int(bbox[0]), 0), max(int(bbox[1]), 0)
                    bbox[2], bbox[3] = min(int(bbox[2]), 500), min(int(bbox[3]), 500)
                    img_crop = image[int(bbox[1]):int(bbox[3]), int(bbox[0]):int(bbox[2])]
                    img_save = np.zeros((32, 32, 9))
                    img_save[:, :, 0:3] = cv2.resize(img_crop[:, :, 3:6], (32, 32))
                    img_save[:, :, 3:6] = cv2.resize(img_crop[:, :, 3:6], (32, 32))
                    img_save[:, :, 6:9] = cv2.resize(img_crop[:, :, 3:6], (32, 32))
                    obj = {'image': img_save, 'label': 0}
                    obj_list.append(obj)

    img_w, img_h = 500, 500
    n = int(len(obj_list) * 0.2)
    for i in range(n):
        img_name = random.choice(os.listdir(os.path.join(root_path, 'val')))
        image_path = os.path.join(root_path, 'val', img_name)
        image = np.load(image_path).astype(np.uint8)
        rand_x, rand_y = random.randint(0, img_w - 10), random.randint(0, img_h - 10)
        img_crop = image[rand_y:rand_y + 10, rand_x:rand_x + 10]
        img_save = np.zeros((32, 32, 9))
        img_save[:, :, 0:3] = cv2.resize(img_crop[:, :, 0:3], (32, 32))
        img_save[:, :, 3:6] = cv2.resize(img_crop[:, :, 3:6], (32, 32))
        img_save[:, :, 6:9] = cv2.resize(img_crop[:, :, 6:9], (32, 32))
        obj = {'image': img_save, 'label': 0}
        obj_list.append(obj)

    print('sample number: ', len(obj_list))

    train_set = VehicleDatasetIteration(obj_list, root_path)
    train_loader = torch.utils.data.DataLoader(dataset=train_set, batch_size=batch_size, shuffle=True)
    model = resnet18(num_classes=2)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device=device)
    optimizer = optim.SGD(model.parameters(), lr=1e-3, momentum=0.9)
    bce = nn.CrossEntropyLoss()
    for epoch in range(epoch):
        running_loss = 0.0
        cnt, cor = 0, 0
        for i, data in enumerate(train_loader):
            inputs, labels = data['image'], data['label']
            inputs, labels = Variable(inputs), Variable(labels)
            optimizer.zero_grad()
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = model(inputs)
            loss = bce(outputs, labels)
            outputs = outputs.detach().cpu().numpy().tolist()
            cats = [i.index(max(i)) for i in outputs]
            labels = labels.detach().cpu().numpy().tolist()
            for i in range(len(cats)):
                if outputs[i][cats[i]] > 0.0 and cats[i] == labels[i]:
                    cor += 1
                    cnt += 1
                elif outputs[i][cats[i]] > 0.0:
                    cnt += 1
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
        print('[%d] loss: %f acc: %f (%d/ %d)' % (epoch + 1, running_loss / len(train_loader), cor / cnt, cor, cnt))
    torch.save(model.state_dict(), 'resnet.pkl')

    return model


if __name__ == "__main__":
    resnet = train_resnet_iteration(
        'D:/Liang/UnsupervisedDetection/exp/WeightPseudoDetection_ResNet18_Skysat/results.json',
        'D:/Liang/Jilin/Skysat/pseudo_0.json',
    )

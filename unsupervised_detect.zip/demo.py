import numpy as np
import random

print(random.randint(1, 10))
print(random.random())

img_w = 1000
img_h = 1000
stride = 500

for i in range(img_w // stride):
    for j in range(img_h // stride):
        stride_x = stride * i
        stride_y = stride * j
        print(stride_x, stride_y)

        # print('evaluating...')
        # with HiddenPrints():
        #     opt = opts().parse()
        #     opt.load_model = r'exp\%s\model_%d.pth' % (opt.exp_id, (epoch + 1))
        #     test(opt)
        # merge(save_path=opt.save_dir)
        # tool = coco.COCO(r'D:\Liang\Jilin\coco\evaluation.json')
        # coco_dets = tool.loadRes(r'exp\{}\merge.json' % (opt.exp_id))
        # coco_eval = COCOeval(tool, coco_dets, "bbox")
        # coco_eval.evaluate()
        # coco_eval.accumulate()
        # coco_eval.summarize()

import torch.optim as optim
from torch import nn
from torch.autograd import Variable
import torch
import time
from models.resnet import resnet50, resnet18
from torchvision import transforms
from torch.utils.data import Dataset, DataLoader
import os
import numpy as np


class VehicleDataset(Dataset):

    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.names_list = os.listdir(root_dir)
        self.size = len(self.names_list)

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        file_name = self.names_list[idx]
        image_path = os.path.join(self.root_dir, file_name)
        image = np.load(image_path)
        label = int(file_name[:-4].split('_')[1])
        image = torch.tensor(image.transpose(2, 0, 1)).float()
        sample = {'image': image, 'label': label}
        return sample


def trainandsave():
    root_path = r"D:\Liang\Jilin\SD\vehicle"
    batch_size = 1024
    epoch = 20

    train = VehicleDataset(root_dir=root_path)

    # val = torchvision.datasets.ImageFolder(
    #     root="root folder path",
    #     transform=transform)

    train_loader = torch.utils.data.DataLoader(dataset=train, batch_size=batch_size, shuffle=True)
    # val_loader = torch.utils.data.DataLoader(dataset=val, batch_size=1, shuffle=True)

    model = resnet18(num_classes=2)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print("device = ", device)
    model.to(device=device)

    optimizer = optim.SGD(model.parameters(), lr=1e-3, momentum=0.9)
    bce = nn.CrossEntropyLoss()

    print('staring training')
    for epoch in range(epoch):
        running_loss = 0.0
        cnt, cor = 0, 0
        for i, data in enumerate(train_loader):
            inputs, labels = data['image'], data['label']
            inputs, labels = Variable(inputs), Variable(labels)
            optimizer.zero_grad()
            inputs = inputs.to(device)
            labels = labels.to(device)
            outputs = model(inputs)

            loss = bce(outputs, labels)

            outputs = outputs.detach().cpu().numpy().tolist()
            cats = [i.index(max(i)) for i in outputs]
            labels = labels.detach().cpu().numpy().tolist()
            for i in range(len(cats)):
                if outputs[i][cats[i]] > 0.0 and cats[i] == labels[i]:
                    cor += 1
                    cnt += 1
                elif outputs[i][cats[i]] > 0.0:
                    cnt += 1

            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        print('[%d] loss: %f acc: %f (%d/ %d)' % (epoch + 1, running_loss / len(train_loader), cor / cnt, cor, cnt))
    torch.save(model.state_dict(), 'resnet.pkl')


if __name__ == "__main__":
    trainandsave()

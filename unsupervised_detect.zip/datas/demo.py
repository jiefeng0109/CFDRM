a=[1]
print(len(a))